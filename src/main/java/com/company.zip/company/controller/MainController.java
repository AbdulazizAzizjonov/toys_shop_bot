package com.company.controller;

import com.company.container.ComponentContainer;
import com.company.enums.CustomerStatus;
import com.company.model.Customer;
import com.company.service.CustomerService;
import com.company.util.KeyboardUtil;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Contact;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.User;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardRemove;

public class MainController {

    public void handleMessage(User user, Message message) {
        if(message.hasText()){
            handleText(user, message);
        }
        else if(message.hasContact()){
            handleContact(user, message);
        }else if(message.hasPhoto()){
            handlePhoto(user, message);
        }
    }

    private void handlePhoto(User user, Message message) {

    }

    private void handleContact(User user, Message message) {
        Contact contact = message.getContact();
        String customerId = String.valueOf(contact.getUserId());

        Customer customer = CustomerService.getCustomerById(customerId);
        if(customer == null){
            customer = new Customer(customerId, contact.getFirstName(),
                    contact.getLastName(), contact.getPhoneNumber(), CustomerStatus.SHARE_CONTACT);
            CustomerService.addCustomer(customer);
        }

        SendMessage sendMessage = new SendMessage(
                String.valueOf(message.getChatId()), "Davomi bor"
        );
        sendMessage.setReplyMarkup(new ReplyKeyboardRemove(true));
        ComponentContainer.MY_TELEGRAM_BOT.sendMsg(sendMessage);
    }

    private void handleText(User user, Message message) {
        String text = message.getText();

        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(String.valueOf(message.getChatId()));
        Customer customer = CustomerService.getCustomerById(String.valueOf(message.getChatId()));

        if(text.equals("/start")){
            if(customer == null){
                sendMessage.setText("Assalomu alaykum!\n\n" +
                        "Raqamingizni jo'nating.");
                sendMessage.setReplyMarkup(KeyboardUtil.contactMarkup());
            }else{
                sendMessage.setText("Siz avval start bosgansiz.");
            }
        }
        else{
            sendMessage.setText("BILMADIM");
        }

        ComponentContainer.MY_TELEGRAM_BOT.sendMsg(sendMessage);
    }


    public void handleCallBack(User user, Message message, String data) {

    }
}
