package com.company.enums;

public enum CustomerStatus {
    STARTED,
    SHARE_CONTACT
}
